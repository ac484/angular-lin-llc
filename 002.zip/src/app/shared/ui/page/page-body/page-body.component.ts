import { Component } from '@angular/core';
import {CommonModule} from '@angular/common';

@Component({
  selector: 'app-page-body',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './page-body.component.html',
  styleUrl: './page-body.component.scss'
})
export class PageBodyComponent {

}
