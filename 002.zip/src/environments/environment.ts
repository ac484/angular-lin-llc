export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyB9aRKduRC2PXUtEcD2SH2L-1jjIeUix-M",
    authDomain: "angular-lin-llc.firebaseapp.com",
    projectId: "angular-lin-llc",
    storageBucket: "angular-lin-llc.firebasestorage.app",
    messagingSenderId: "590581941286",
    appId: "1:590581941286:web:e8509cb6b92c40704652e7",
    measurementId: "G-CX9CWFLT78",
    recaptchaV3SiteKey: '6LccRXcrAAAAAI4E9z0NZcujBZ9EnyDJZLLlg9Fp'
  }
}; 
